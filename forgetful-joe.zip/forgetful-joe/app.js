const express = require('express');
const bodyParser = require('body-parser');
const validator = require('validator');
const xssFilters = require('xss-filters');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();

// App settings.
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(cookieParser());

// Public routes.
app.get('/', (req, res) => {
    res.render('layout', { title: 'Home', page: 'home' });
});
app.get('/about', (req, res) => {
    res.render('layout', { title: 'About', page: 'about' });
});
app.get('/faq', (req, res) => {
    res.render('layout', { title: 'FAQ', page: 'faq' });
});
app.get('/donate', (req, res) => {
    res.render('layout', { title: 'Donate', page: 'donate' });
});
app.get('/privacy-policy', (req, res) => {
    res.render('layout', { title: 'Privacy Policy', page: 'privacy-policy' });
});

// User routes.
const JWT_SECRET = 'NOT_SO_SECRET_KEY';
let admin = require("firebase-admin");

let serviceAccount = require(path.join(__dirname, "serviceAccountKey.json"));

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://forgetfuljoe-2bcd8-default-rtdb.firebaseio.com"
});

// JWT authentication middleware
function authIt(req, res, next) {
    const token = req.cookies.forgetfuljoe;

    if (!token) {
        return res.redirect('/login'); // Redirect to login if no token
    }

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.redirect('/login'); // Redirect to login on verification error
        }
        req.userId = decoded.userId; // Store decoded userId in request object
        next(); // Proceed to next middleware or route handler
    });
}
app.get('/login', (req, res) => {

    // Check if the user is already logged in.
    if (req.cookies.forgetfuljoe) {
        // Get the id from the JWT token.
        const token = req.cookies.forgetfuljoe;
        const decoded = jwt.verify(token, JWT_SECRET);
        return res.redirect('/dashboard/' + decoded.userId);
    }

    // Check if the status query parameter exists.
    const status = req.query.status;

    // Render the login page with the status.
    res.render('layout', { title: 'Login', page: 'login', status });
});
app.post('/signup', async (req, res) => {
    
        // Get name, email and password from the request body.
        const { name, email, password } = req.body;
    
        // Validate name, email and password.
        if (!validator.isEmail(email) || !validator.isLength(password, { min: 8 })) {
            return res.redirect('/login?status=bad-signup');
        }
    
        // Sanitize name, email and password.
        const sanitizedName = xssFilters.inHTMLData(name);
        const sanitizedEmail = xssFilters.inHTMLData(email);
        const sanitizedPassword = xssFilters.inHTMLData(password);
    
        // Hash the password.
        const hashedPassword = await bcrypt.hash(sanitizedPassword, 10);
    
        
        try {
            const db = admin.database();
            const usersRef = db.ref('users');

            // Fetch user data from the database
            const snapshot = await usersRef.once('value');
            const usersData = snapshot.val();

            // Check if the email already exists
            const userExists = Object.values(usersData).some(u => u.email === sanitizedEmail);
            if (userExists) {
                return res.redirect('/login?status=email-exists');
            }

            // Add the user to the database
            const newUserRef = usersRef.push();
            const newUser = {
                id: newUserRef.key,
                name: sanitizedName,
                email: sanitizedEmail,
                password: hashedPassword,
                expiries: [
                    {
                        name: 'Drivers License',
                        expiry: new Date().toISOString().slice(0, 10)
                    },
                    {
                        name: 'Passport',
                        expiry: new Date().toISOString().slice(0, 10)
                    }
                ]
            };
            await newUserRef.set(newUser);

        } catch (error) {
            console.error(error);
            return res.redirect('/login?status=create-error');
        }

        // Redirect to login with a success status.
        res.redirect('/login?status=success');
});
app.post('/login', async (req, res) => {

    // Get email and password from the request body.
    const { email, password } = req.body;

    // Validate email and password.
    if (!validator.isEmail(email) || !validator.isLength(password, { min: 8 })) {
        return res.redirect('/login?status=bad-login');
    }

    // Sanitize email.
    const sanitizedEmail = xssFilters.inHTMLData(email);

    // Sanitize password.
    const sanitizedPassword = xssFilters.inHTMLData(password);

    // Fetch user data from the database
    const db = admin.database();
    const usersRef = db.ref('users');
    const snapshot = await usersRef.once('value');
    const usersData = snapshot.val();

    // Authenticate user.
    const user = Object.values(usersData).find(u => u.email === sanitizedEmail);
    const passwordMatch = await bcrypt.compare(sanitizedPassword, user.password);
    if (!passwordMatch || !user) {
        return res.redirect('/login?status=bad-login');
    }

    // Generate JWT token
    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '24h' });

    // Store JWT token in a cookie
    res.cookie('forgetfuljoe', token, { httpOnly: true, maxAge: 24 * 60 * 60 * 1000 });

    // Redirect to dashboard or another protected route
    res.redirect('/dashboard/' + user.id);
});
app.get('/logout', (req, res) => {
    res.clearCookie('forgetfuljoe');
    res.redirect('/');
});
app.get('/dashboard/:id', authIt, async (req, res) => {

    // Get the id from the URL.
    let id = req.params.id.trim();

    // Check that the id is the id from the JWT token.
    let token = req.cookies.forgetfuljoe;
    let decoded = jwt.verify(token, JWT_SECRET);
    if (id !== decoded.userId) {
        req.clearCookie('forgetfuljoe');
        return res.redirect('/login');
    }

    // Get the users from the database.
    try{
        const db = admin.database();
        const usersRef = db.ref('users');
        const snapshot = await usersRef.once('value');
        const usersData = snapshot.val();

        // Find the user.
        const user = Object.values(usersData).find(u => u.id === id);

        // Get the user's expiries renewals.
        const expiriesData = user.expiries;
        const expiries = expiriesData.map(expiry => {
            return {
                name: expiry.name,
                expiry: new Date(expiry.expiry).toISOString().slice(0, 10).toString()
            };
        });

        // Get the user's name.
        const username = user.name;

        res.render('layout', { title: 'Dashboard', page: 'dashboard', username, expiries, id: req.params.id});
    } catch (error) {
        return res.redirect('/login?status=fetch-error');
    }
});
app.post('/delete/:id', authIt, async (req, res) => {
    
    // Get the id from the URL.
    const id = req.params.id;

    // Get the expiry name from query parameters.
    const expiryName = req.body.expiryName;

    try{
        // Fetch user data from the database
        const db = admin.database();
        const usersRef = db.ref('users');
        const snapshot = await usersRef.once('value');
        const usersData = snapshot.val();

        // Find the user.
        const user = Object.values(usersData).find(u => u.id === id);

        // Get the user's expiries renewals.
        const expiriesData = user.expiries;

        // Filter out the expiry to delete.
        const updatedExpiries = expiriesData.filter(expiry => expiry.name !== expiryName);

        // Update the user's expiries renewals.
        await usersRef.child(id).update({ expiries: updatedExpiries });

        // Redirect to the dashboard.
        res.redirect('/dashboard/' + id);
    } catch (error) {
        return res.redirect('/dashboard/' + id + '?status=delete-error');
    }
});
app.post('/edit/:id', authIt, async (req, res) => {
        
    // Get the id from the URL.
    const id = req.params.id.trim();

    // Check that the id is the id from the JWT token.
    let token = req.cookies.forgetfuljoe;
    let decoded = jwt.verify(token, JWT_SECRET);
    if (id !== decoded.userId) {
        req.clearCookie('forgetfuljoe');
        return res.redirect('/login');
    }

    // Get the expiry name and expiry date from the request body.
    const expiryName = req.body.name;
    const expiryDate = req.body.expiry;

    try{
        // Fetch user data from the database
        const db = admin.database();
        const usersRef = db.ref('users');
        const snapshot = await usersRef.once('value');
        const usersData = snapshot.val();

        // Find the user.
        const user = Object.values(usersData).find(u => u.id === id);

        // Get the user's expiries renewals.
        const expiriesData = user.expiries;

        // Update the expiry date.
        const updatedExpiries = expiriesData.map(expiry => {
            if (expiry.name === expiryName) {
                return { name: expiry.name, expiry: expiryDate };
            }
            return expiry;
        });

        // Update the user's expiries renewals.
        await usersRef.child(id).update({ expiries: updatedExpiries });

        // Redirect to the dashboard.
        res.redirect('/dashboard/' + id);
    } catch (error) {
        return res.redirect('/dashboard/' + id + '?status=edit-error');
    }
});
app.get('/add/:id', authIt, (req, res) => {
    res.render('layout', { title: 'Add', page: 'add', id: req.params.id.trim() });
});
app.post('/add/:id', authIt, async (req, res) => {

    // Get the id from the URL.
    const id = req.params.id.trim();

    // Check that the id is the id from the JWT token.
    let token = req.cookies.forgetfuljoe;
    let decoded = jwt.verify(token, JWT_SECRET);
    if (id !== decoded.userId) {
        req.clearCookie('forgetfuljoe');
        return res.redirect('/login');
    }

    // Get the expiry name and expiry date from the request body.
    const name = req.body.name;
    const expiry = req.body.expiry;

    try{
        // Fetch user data from the database
        const db = admin.database();
        const usersRef = db.ref('users');
        const snapshot = await usersRef.once('value');
        const usersData = snapshot.val();

        // Find the user.
        const user = Object.values(usersData).find(u => u.id === id);

        // Get the user's expiries renewals.
        const expiriesData = user.expiries;

        // Add the new expiry renewal.
        const updatedExpiries = [...expiriesData, { name, expiry }];

        // Update the user's expiries renewals.
        await usersRef.child(id).update({ expiries: updatedExpiries });

        // Redirect to the dashboard.
        res.redirect('/dashboard/' + id);
    } catch (error) {
        return res.redirect('/dashboard/' + id + '?status=add-error');
    }

});
app.get('/help/:id', authIt, (req, res) => {
    res.render('layout', { title: 'Help', page: 'help', id: req.params.id.trim() });
});

// Error handling.
app.use((req, res) => {
    res.status(404).render('layout', { title: '404', page: '404' });
});

// Start the server
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
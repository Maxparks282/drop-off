document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit');
    const cancelButtons = document.querySelectorAll('.cancel');
    const deleteButtons = document.querySelectorAll('.delete');
    const cancelDeleteButtons = document.querySelectorAll('.cancel-delete');
    const editForms = document.querySelectorAll('.edit-form');
    const deleteForms = document.querySelectorAll('.delete-form');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const index = this.getAttribute('data-index');
            document.getElementById('edit' + index).style.display = 'block';
        });
    });

    cancelButtons.forEach(button => {
        button.addEventListener('click', function () {
            const index = this.getAttribute('data-index');
            document.getElementById('edit' + index).style.display = 'none';
        });
    });

    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const index = this.getAttribute('data-index');
            document.getElementById('delete' + index).style.display = 'block';
        });
    });

    cancelDeleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const index = this.getAttribute('data-index');
            document.getElementById('delete' + index).style.display = 'none';
        });
    });

    editForms.forEach(form => {
        form.style.display = 'none'; // Initially hide all edit forms
    });

    deleteForms.forEach(form => {
        form.style.display = 'none'; // Initially hide all delete forms
    });
});
document.getElementById('signup').addEventListener('change', function() {
    document.getElementById('signupform').style.display = this.checked ? 'flex' : 'none';
    document.getElementById('loginform').style.display = this.checked ? 'none' : 'flex';
});

document.getElementById('login').addEventListener('change', function() {
    document.getElementById('loginform').style.display = this.checked ? 'flex' : 'none';
    document.getElementById('signupform').style.display = this.checked ? 'none' : 'flex';
});
document.addEventListener('DOMContentLoaded', function () {
    const deleteAccountBtn = document.getElementById('delete-account-btn');
    const deleteAccountForm = document.getElementById('delete-account-form');
    const cancelDeleteAccountBtn = document.getElementById('cancel-delete-account-btn');

    deleteAccountBtn.addEventListener('click', function () {
        deleteAccountForm.style.display = 'block';
    });

    cancelDeleteAccountBtn.addEventListener('click', function () {
        deleteAccountForm.style.display = 'none';
    });

    deleteAccountForm.style.display = 'none'; // Initially hide the form
});